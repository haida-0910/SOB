from django.contrib import admin
from .models import SobModel

# Register your models here.

admin.site.register(SobModel)
