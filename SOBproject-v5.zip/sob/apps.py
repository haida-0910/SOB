from django.apps import AppConfig


class SobConfig(AppConfig):
    name = 'sob'


